# Import required libraries
from AppOpener import close, open as appopen  # Import functions to open and close apps.
from webbrowser import open as webopen  # Import web browser functionality.
from pywhatkit import search, playonyt  # Import functions for Google search and YouTube playback.
from dotenv import dotenv_values  # Import dotenv to manage environment variables.
from bs4 import BeautifulSoup  # Import BeautifulSoup for HTML parsing.
from rich import print  # Import rich for styled console outputs.
from groq import Groq  # Import Groq for AI chat functionalities.
import webbrowser  # Import webbrowser for web browsing functionalities.
import subprocess  # Import subprocess for interacting with the system.
import requests  # Import requests for making HTTP requests.
import keyboard  # Import keyboard for simulating key presses.
import asyncio  # Import asyncio for asynchronous programming.
import os  # Import os for operating system functionalities.
import pyautogui  # For taking screenshots
import datetime   # For timestamps
import math       # For calculator
import glob       # For file search
import re         # For pattern matching

# Define the recognized functions locally to avoid circular imports
KNOWN_FUNCTIONS = [
    "open", "close", "play", "system", "content", "google search", 
    "youtube search", "set language", "change voice", "generate image",
    "download", "translate", "weather", "calculator", "email",
    "schedule", "take screenshot", "record", "navigate", "find file",
    "summarize", "social media", "shop", "news", "music", "video call",
    "general", "realtime", "workflow"
]

# Load environment variables from the .env file.
env_vars = dotenv_values(".env")
GroqAPIKey = env_vars.get("GroqAPIKey")  # Retrieve the Groq API key.

# Define CSS classes for parsing specific elements in HTML content.
classes = ["zCubwf", "hgKElc", "LTKOO SY7ric", "Z0LcW", "gsrt vk_bk FzvWSb  YwPhnf", "pclqee", "tw-Data-text tw-text-small tw-ta",
           "IZ6rdc", "05uR6d LTKOO", "vlzY6d", "webanswers-webanswers_table_webanswers-table", "dDoNo ikb4Bb gsrt", "sXLaOe",
           "LWkfXe", "VQF4g", "qv3Wpe", "kno-rdesc", "SPZz6b"]

# Define a user-agent for making web requests.
useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36'

# Initialize the Groq client with the API key.
client = Groq(api_key=GroqAPIKey)

# Predefined professional responses for user interactions.
professional_responses = [
    "Your satisfaction is my top priority; feel free to reach out if there's anything else I can help you with.",
    "I'm at your service for any additional questions or support you may need—don't hesitate to ask."
]

# List to store chatbot messages.
messages = []

# System message to provide context to the chatbot.
SystemChatBot = [{"role": "system","content": f"Hello, I am {os.environ['Username']}, You're a content writer. You have to write content like letters"}]

# Function to perform a Google search.
def GoogleSearch(topic):
    try:
        print(f"Searching Google for: {topic}")
        search(topic)  # Use pywhatkit's search function to perform a Google search.
        print(f"Successfully opened Google search for: {topic}")
        return True  # Indicate success.
    except Exception as e:
        print(f"Error searching Google: {str(e)}")
        try:
            # Fallback using direct URL
            query_formatted = topic.replace(" ", "+")
            webopen(f"https://www.google.com/search?q={query_formatted}")
            print(f"Opened Google search (fallback) for: {topic}")
            return True
        except Exception as inner_e:
            print(f"Fallback error for Google search: {str(inner_e)}")
            return False

# Function to generate content using AI and save it to a file.
def Content(topic):
    # Nested function to open a file in Notepad.
   
    def OpenNotepad(file):
        default_text_editor = 'notepad.exe'  # Default text editor.
        subprocess.Popen([default_text_editor, file])  # Open the file in Notepad.

    # Nested function to generate content using the AI chatbot.
    def ContentWriterAI(prompt):
        messages.append({"role": "user", "content": f"{prompt}"})  # Add the user's prompt to messages.
        completion = client.chat_completions.create(
            model="mixtral-8x7b-32768",  # Specify the AI model.
            messages=SystemChatBot + messages,  # Include system instructions and chat history.
            max_tokens=2048,  # Limit the maximum tokens in the response.
            temperature=0.7,  # Adjust response randomness.
            top_p=1,  # Use nucleus sampling for response diversity.
            stream=True,  # Enable streaming response.
            stop=None  # Allow the model to determine stopping conditions.
        )
        Answer = ""  # Initialize an empty string for the response.
        # Process streamed response chunks.
        for chunk in completion:
            if chunk.choices[0].delta.content:  # Check for content in the current chunk.
                Answer += chunk.choices[0].delta.content  # Append the content to the answer.
        Answer = Answer.replace("</s>", "")  # Remove unwanted tokens from the response.
        messages.append({"role": "assistant", "content": Answer})  # Add the AI's response to messages.
        return Answer

    topic_clean = str(topic.replace("Content ", ""))  # Remove "Content " from the topic.
    ContentByAI = ContentWriterAI(topic_clean)  # Generate content using AI.
    # Save the generated content to a text file.
    with open(rf"Data/{topic_clean.lower().replace(' ', '')}.txt", "w", encoding="utf-8") as file:
        file.write(ContentByAI)  # Write the content to the file.
        file.close()
    OpenNotepad(rf"Data/{topic_clean.lower().replace(' ', '')}.txt")  # Open the file in Notepad.
    return True  # Indicate success.

# Function to search for a topic on YouTube.
def YouTubeSearch(Topic):
    try:
        print(f"Searching YouTube for: {Topic}")
        query_formatted = Topic.replace(" ", "+")
        Url4Search = f"https://www.youtube.com/results?search_query={query_formatted}"  # Construct the YouTube search URL.
        webbrowser.open(Url4Search) # Open the search URL in a web browser.
        print(f"Successfully opened YouTube search for: {Topic}")
        return True  # Indicate success.
    except Exception as e:
        print(f"Error searching YouTube: {str(e)}")
        try:
            # Fallback using a different method
            webopen(f"https://www.google.com/search?q={Topic}+youtube")
            print(f"Opened Google search for YouTube content: {Topic}")
            return True
        except Exception as inner_e:
            print(f"Fallback error for YouTube search: {str(inner_e)}")
            return False

# Function to play a video on YouTube.
def PlayYoutube(query):
    try:
        print(f"Attempting to play YouTube video: {query}")
        playonyt(query)  # Use pywhatkit's playonyt function to play the video.
        print(f"Successfully initiated YouTube playback for: {query}")
        return True  # Indicate success.
    except Exception as e:
        print(f"Error playing YouTube video: {str(e)}")
        try:
            # Fallback: search YouTube directly
            query_formatted = query.replace(" ", "+")
            webopen(f"https://www.youtube.com/results?search_query={query_formatted}")
            print(f"Opened YouTube search for: {query}")
            return True
        except Exception as inner_e:
            print(f"Fallback error for YouTube: {str(inner_e)}")
            return False

# Function to open an application or a relevant webpage.
def OpenApp(app, sess=requests.session()):
    print(f"Attempting to open: {app}")  # Add debug output
    try:
        appopen(app, match_closest=True, output=True, throw_error=True)  # Attempt to open the app.
        print(f"Successfully opened: {app}")  # Add debug output
        return True  # Indicate success.
    
    except Exception as e:
        print(f"Error opening app {app}: {str(e)}")  # Add debug output
        try:
            def extract_links(html):
                if html is None:
                    return []
                soup = BeautifulSoup(html, 'html.parser')  # Parse the HTML content.
                links = soup.find_all('a', {"jsname": 'UwckNb'})  # Find relevant links.
                if not links:
                    return []
                return [link.get('href') for link in links]  # Return the links.

            # Nested function to perform a Google search and retrieve HTML.
            def search_google(query):
                url = f"https://www.google.com/search?q={query}"  # Construct the Google search URL.
                headers = {"User-Agent": useragent}  # Use the predefined user-agent.
                response = sess.get(url, headers=headers)  # Perform the GET request.
       
                if response.status_code == 200:
                    return response.text  # Return the HTML content.
                else:
                    print("Failed to retrieve search results.")  # Print an error message.
                    return None
        
            html = search_google(app)  # Perform the Google search.

            if html:
                links = extract_links(html)
                if links:
                    link = links[0]  # Extract the first link from the search results.
                    print(f"Opening website for {app}: {link}")  # Add debug output
                    webopen(link)  # Open the link in a web browser.
                    return True  # Indicate success.
                else:
                    print(f"No links found for {app}")
                    webopen(f"https://www.google.com/search?q={app}")  # Fallback to Google search
                    return True
            else:
                print(f"Failed to search for {app}")
                # As a fallback, just open Google with the app as the search term
                webopen(f"https://www.google.com/search?q={app}")
                return True
        except Exception as inner_e:
            print(f"Fallback error for {app}: {str(inner_e)}")
            # As a last resort, just try to open the app as a website
            try:
                webopen(f"https://{app}.com")
                return True
            except:
                return False  # Indicate failure if all methods fail.

# Function to close an application.
def CloseApp(app):

    if "chrome" in app:
        pass  # Skip if the app is Chrome.
    else:
        try:
            close(app, match_closest=True, output=True, throw_error=True)  # Attempt to close the app.
            return True  # Indicate success.
        except:
            return False  # Indicate failure.

# Function to execute system-level commands.
def System(command):
    # Nested function to mute the system volume.
    def mute():
        keyboard.press_and_release("volume mute")  # Simulate the mute key press.

    # Nested function to unmute the system volume.
    def unmute():
        keyboard.press_and_release("volume mute")  # Simulate the unmute key press.

    # Nested function to increase the system volume.
    def volume_up():
        keyboard.press_and_release("volume up")  # Simulate the volume up key press.

    # Nested function to decrease the system volume.
    def volume_down():
        keyboard.press_and_release("volume down")  # Simulate the volume down key press.

    # Execute the appropriate command.
    if command == "mute":
        mute()
    elif command == "unmute":
        unmute()
    elif command == "volume up":
        volume_up()
    elif command == "volume down":
        volume_down()
    return True  # Indicate success.

# Function to download content
def Download(query):
    try:
        print(f"Attempting to download: {query}")
        # This is a placeholder - we'll open a browser to relevant download source
        if "youtube" in query.lower() or "video" in query.lower():
            webopen("https://www.y2mate.com/")
            print(f"Opened YouTube video downloader")
        elif "music" in query.lower() or "song" in query.lower() or "audio" in query.lower():
            webopen("https://mp3converter.net/")
            print(f"Opened music/audio downloader")
        elif "image" in query.lower() or "photo" in query.lower() or "picture" in query.lower():
            search(f"download {query}")
            print(f"Searching for image downloads")
        elif "software" in query.lower() or "app" in query.lower() or "program" in query.lower():
            webopen(f"https://softonic.com/s/{query.replace(' ', '-')}")
            print(f"Opened software download search")
        else:
            search(f"download {query}")
            print(f"Searching for download: {query}")
        return True
    except Exception as e:
        print(f"Error starting download: {str(e)}")
        try:
            webopen(f"https://www.google.com/search?q=download+{query.replace(' ', '+')}")
            return True
        except:
            return False

# Function to translate text
def Translate(query):
    try:
        print(f"Translating: {query}")
        # Extract target language if specified
        target_language = "English"  # Default
        if "to " in query:
            parts = query.split("to ")
            if len(parts) > 1:
                target_language = parts[1].strip()
                query = parts[0].strip()
        
        # Open Google Translate with the query
        webopen(f"https://translate.google.com/?sl=auto&tl=en&text={query.replace(' ', '%20')}&op=translate")
        print(f"Opened translator for: {query}")
        return True
    except Exception as e:
        print(f"Error translating: {str(e)}")
        try:
            # Fallback to a simple Google search
            search(f"translate {query}")
            return True
        except:
            return False

# Function to get weather information
def Weather(location="current location"):
    try:
        print(f"Getting weather for: {location}")
        # Open a weather service with the location
        if location.lower() == "current location" or not location:
            webopen("https://www.accuweather.com/")
        else:
            webopen(f"https://www.accuweather.com/en/search-locations?query={location.replace(' ', '%20')}")
        print(f"Opened weather information for: {location}")
        return True
    except Exception as e:
        print(f"Error getting weather: {str(e)}")
        try:
            search(f"weather {location}")
            return True
        except:
            return False

# Function to calculate expressions
def Calculator(expression):
    try:
        print(f"Calculating: {expression}")
        # Basic sanitization to prevent code injection
        sanitized = expression.replace("^", "**")  # Convert ^ to Python's ** for exponentiation
        
        # Handle percentage calculations
        if "%" in sanitized:
            sanitized = sanitized.replace("%", "/100")
        
        # Handle basic mathematical operations
        sanitized = sanitized.replace("×", "*").replace("÷", "/")
        sanitized = sanitized.replace("x", "*")
        
        # Handle square root
        if "sqrt" in sanitized.lower():
            sanitized = sanitized.lower().replace("sqrt", "math.sqrt")
        
        # Handle common words
        sanitized = sanitized.lower().replace("plus", "+").replace("minus", "-")
        sanitized = sanitized.replace("times", "*").replace("divided by", "/")
        
        # Evaluate the expression
        result = eval(sanitized)
        print(f"Result: {result}")
        
        # Return both the expression and the result
        return f"{expression} = {result}"
    except Exception as e:
        print(f"Error calculating: {str(e)}")
        try:
            # Fallback to a web calculator
            search(f"calculate {expression}")
            return True
        except:
            return False

# Function to take a screenshot
def TakeScreenshot():
    try:
        print("Taking screenshot")
        # Create a timestamp for the filename
        timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        # Define the screenshot path
        screenshot_path = f"Data/screenshot_{timestamp}.png"
        # Take the screenshot
        screenshot = pyautogui.screenshot()
        # Save the screenshot
        screenshot.save(screenshot_path)
        print(f"Screenshot saved to: {screenshot_path}")
        
        # Open the screenshot
        subprocess.Popen(['start', screenshot_path], shell=True)
        return True
    except Exception as e:
        print(f"Error taking screenshot: {str(e)}")
        return False

# Function to find files
def FindFile(query):
    try:
        print(f"Searching for file: {query}")
        # Clean up the query
        query = query.lower().strip()
        # Default search locations
        search_paths = [
            os.path.join(os.environ['USERPROFILE'], 'Documents', f'*{query}*.*'),
            os.path.join(os.environ['USERPROFILE'], 'Downloads', f'*{query}*.*'),
            os.path.join(os.environ['USERPROFILE'], 'Desktop', f'*{query}*.*'),
            os.path.join(os.environ['USERPROFILE'], 'Pictures', f'*{query}*.*'),
            os.path.join(os.environ['USERPROFILE'], 'Videos', f'*{query}*.*'),
            os.path.join(os.environ['USERPROFILE'], 'Music', f'*{query}*.*')
        ]
        
        # Search for matching files
        found_files = []
        for path in search_paths:
            found_files.extend(glob.glob(path))
        
        # If files were found, open the first one
        if found_files:
            print(f"Found {len(found_files)} files matching '{query}'")
            print(f"Opening: {found_files[0]}")
            subprocess.Popen(['start', found_files[0]], shell=True)
            return True
        else:
            print(f"No files found matching '{query}'")
            # If no files found, offer to search for them
            webopen(f"https://www.google.com/search?q={query}+file")
            return True
    except Exception as e:
        print(f"Error finding file: {str(e)}")
        return False

# Asynchronous function to translate and execute user commands.
async def TranslateAndExecute(commands: list[str]):

    funcs = []  # List to store asynchronous tasks.

    for command in commands:

        if command.startswith("workflow "):  # Handle workflow commands
            workflow_name = command.removeprefix("workflow ")
            fun = asyncio.to_thread(execute_workflow, workflow_name)  # Schedule workflow execution
            funcs.append(fun)

        elif command.startswith("open "):  # Handle "open" commands.

            if "open it" in command:  # Ignore "open it" commands.
                pass
            elif "open file" == command:  # Ignore "open file" commands.
                pass

            else:
                fun = asyncio.to_thread(OpenApp, command.removeprefix("open "))  # Schedule app opening.
                funcs.append(fun)

        elif command.startswith("general "):  # Handle general commands
            # Pass through general commands for processing by chatbot
            yield f"general {command.removeprefix('general ')}"

        elif command.startswith("realtime "):  # Handle real-time commands
            # Pass through realtime commands for processing by search engine
            yield f"realtime {command.removeprefix('realtime ')}"

        elif command.startswith("close "):  # Handle "close" commands.
            fun = asyncio.to_thread(CloseApp, command.removeprefix("close "))  # Schedule app closing.
            funcs.append(fun)
        elif command.startswith("play "):  # Handle "play" commands.
            fun = asyncio.to_thread(PlayYoutube, command.removeprefix("play "))  # Schedule YouTube playback.
            funcs.append(fun)
        elif command.startswith("content "):  # Handle "content" commands.
            fun = asyncio.to_thread(Content, command)  # Schedule content creation.
            funcs.append(fun)
        elif command.startswith("google search "):  # Handle Google search commands.
            fun = asyncio.to_thread(GoogleSearch, command.removeprefix("google search "))  # Schedule Google search.
            funcs.append(fun)
        elif command.startswith("youtube search "):  # Handle YouTube search commands.
            fun = asyncio.to_thread(YouTubeSearch, command.removeprefix("youtube search "))  # Schedule YouTube search.
            funcs.append(fun)
        elif command.startswith("system "):  # Handle system commands.
            fun = asyncio.to_thread(System, command.removeprefix("system "))  # Schedule system command.
            funcs.append(fun)
        elif command.startswith("download "):  # Handle download commands.
            fun = asyncio.to_thread(Download, command.removeprefix("download "))  # Schedule download.
            funcs.append(fun)
        elif command.startswith("translate "):  # Handle translate commands.
            fun = asyncio.to_thread(Translate, command.removeprefix("translate "))  # Schedule translation.
            funcs.append(fun)
        elif command.startswith("weather "):  # Handle weather commands.
            fun = asyncio.to_thread(Weather, command.removeprefix("weather "))  # Schedule weather lookup.
            funcs.append(fun)
        elif command.startswith("calculator "):  # Handle calculator commands.
            fun = asyncio.to_thread(Calculator, command.removeprefix("calculator "))  # Schedule calculation.
            funcs.append(fun)
        elif command.startswith("take screenshot"):  # Handle screenshot commands.
            fun = asyncio.to_thread(TakeScreenshot)  # Schedule screenshot.
            funcs.append(fun)
        elif command.startswith("find file "):  # Handle file search commands.
            fun = asyncio.to_thread(FindFile, command.removeprefix("find file "))  # Schedule file search.
            funcs.append(fun)
        else:
            print(f"No Function Found. For {command}")  # Print an error for unrecognized commands.
    results = await asyncio.gather(*funcs)  # Execute all tasks concurrently.
    for result in results:  # Process the results.
        if isinstance(result, str):
            yield result
        else:
            yield result

# Add a smart task handler class to interpret ambiguous requests
class SmartTaskHandler:
    def __init__(self):
        # Initialize context tracking
        self.context = {
            "last_task": None,
            "last_query": None,
            "active_apps": set(),
            "recent_topics": [],
            "user_preferences": {},
            "session_start": datetime.datetime.now()
        }
        
        # Enhanced task patterns with Bengali language support
        self.task_patterns = {
            # Original patterns
            # Video/media patterns
            r"(?:watch|view|see|play|show).*(?:video|videos|movie|movies|clip).*(?:about|on|of)?\s+(.+)": 
                lambda x: f"youtube search {x}",
            r"(?:listen to|play).*(?:song|music|audio|track).*(?:by|from)?\s+(.+)":
                lambda x: f"play {x}",
            
            # Search patterns
            r"(?:find|search for|look up|google).*(?:information|info|details|about)\s+(.+)": 
                lambda x: f"google search {x}",
            r"(?:what is|who is|tell me about|show me)\s+(.+)": 
                lambda x: f"realtime {x}",
            r"(?:open|visit|go to).*(?:website|site|webpage).*(?:for|about)?\s+(.+)":
                lambda x: f"open {x}",
            
            # App control patterns
            r"(?:start|launch|run|execute|open|begin)\s+(.+)": 
                lambda x: f"open {x}",
            r"(?:stop|quit|exit|terminate|close|end)\s+(.+)": 
                lambda x: f"close {x}",
            
            # Weather patterns
            r"(?:how's the weather|what's the weather like|temperature|forecast|weather report)(?:\s+in\s+(.+))?": 
                lambda x: f"weather {x if x else 'current location'}",
            r"(?:will it rain|is it going to be sunny)(?:\s+in\s+(.+))?":
                lambda x: f"weather {x if x else 'current location'}",
            
            # Calculation patterns
            r"(?:calculate|compute|what is|what's|solve)\s+(.+)": 
                lambda x: f"calculator {x}" if any(op in x for op in ['+', '-', '*', '/', '%', 'plus', 'minus', 'times', 'divided']) else None,
            r"(?:what is|what's).*(?:sum|product|difference|quotient).*(?:of|between)\s+(.+)":
                lambda x: f"calculator {x}",
            
            # Screenshot patterns
            r"(?:capture|take a picture of|snap|screenshot)(?:\s+my)?\s+(?:screen|display)": 
                lambda x: "take screenshot",
            r"(?:save|record).*(?:what's on|what is on).*(?:screen|display)":
                lambda x: "take screenshot",
            
            # File patterns
            r"(?:locate|find|where is|search for)(?:\s+my)?\s+(?:file|document|pdf|spreadsheet|presentation|image|photo)(?:\s+(?:named|called))?\s+(.+)": 
                lambda x: f"find file {x}",
            r"(?:open|show|display)(?:\s+my)?\s+(?:file|document|pdf|spreadsheet)(?:\s+(?:named|called))?\s+(.+)":
                lambda x: f"find file {x}",
            
            # Download patterns
            r"(?:download|get|save|grab|fetch)(?:\s+this)?\s+(?:file|video|song|audio|music|image|photo|software|app|program)(?:\s+(?:from|on))?\s+(.+)?": 
                lambda x: f"download {x if x else 'current item'}",
            r"(?:save|store).*(?:copy of|version of).*(?:from|at)\s+(.+)":
                lambda x: f"download {x}",
            
            # Translation patterns
            r"(?:translate|convert|change|interpret)(?:\s+the\s+(?:text|phrase|word|sentence))?\s+(.+?)(?:\s+(?:to|into)\s+(.+))?": 
                lambda x, y=None: f"translate {x}{' to '+y if y else ''}",
            r"(?:what is|how to say).*(?:\s+in\s+(.+))\s+language\??$":
                lambda x: f"translate the previous text to {x}",
            
            # Content creation patterns
            r"(?:write|create|draft|compose|generate)(?:\s+a|an)?\s+(?:email|letter|report|essay|document|story|blog post|article)(?:\s+about|on|for)?\s+(.+)": 
                lambda x: f"content {x}",
            r"(?:help me|assist me)(?:\s+with)?\s+(?:writing|creating|drafting)(?:\s+a|an)?\s+(?:email|letter|report|document)(?:\s+about|on)?\s+(.+)":
                lambda x: f"content {x}",
                
            # Workflow patterns
            r"(?:start|begin|run|execute)\s+(?:my)?\s+(?:morning routine|work setup|entertainment|study setup|development environment)": 
                lambda x: f"workflow {x.split()[-2] + '_' + x.split()[-1]}",
            r"(?:prepare|get ready|setup)\s+(?:for|my)?\s+(?:work|study|entertainment|gaming|writing|development|media production)": 
                lambda x: f"workflow {x.split()[-1]}_setup",
            
            # Bengali patterns (added support for Bengali language commands)
            # Video/media patterns in Bengali
            r"(?:দেখাও|দেখতে চাই|প্লে করো).*(?:ভিডিও|মুভি|সিনেমা|ক্লিপ).*(?:সম্পর্কে|বিষয়ে)?\s+(.+)": 
                lambda x: f"youtube search {x}",
            r"(?:শোনাও|প্লে করো).*(?:গান|সঙ্গীত|মিউজিক).*(?:দ্বারা|থেকে)?\s+(.+)":
                lambda x: f"play {x}",
            
            # Search patterns in Bengali
            r"(?:খোঁজ|খুঁজে দেখাও|সন্ধান করো|গুগল).*(?:তথ্য|ইনফরমেশন|ডিটেলস|সম্পর্কে)\s+(.+)": 
                lambda x: f"google search {x}",
            r"(?:কি|কে|সম্পর্কে বলো|দেখাও)\s+(.+)": 
                lambda x: f"realtime {x}",
            r"(?:খোলো|ভিজিট করো|যাও).*(?:ওয়েবসাইট|সাইট).*(?:জন্য|সম্পর্কে)?\s+(.+)":
                lambda x: f"open {x}",
            
            # App control patterns in Bengali
            r"(?:খোলো|চালু করো|রান করো|শুরু করো|এক্সিকিউট করো)\s+(.+)": 
                lambda x: f"open {x}",
            r"(?:বন্ধ করো|শেষ করো|টার্মিনেট করো|এক্সিট করো)\s+(.+)": 
                lambda x: f"close {x}",
            
            # Weather patterns in Bengali
            r"(?:আবহাওয়া কেমন|তাপমাত্রা কত|বাইরে কেমন)(?:\s+(?:এ|তে)\s+(.+))?": 
                lambda x: f"weather {x if x else 'current location'}",
            r"(?:বৃষ্টি হবে|রোদ হবে)(?:\s+(?:এ|তে)\s+(.+))?":
                lambda x: f"weather {x if x else 'current location'}",
            
            # Calculation patterns in Bengali
            r"(?:ক্যালকুলেট করো|গণনা করো|কত হয়|সমাধান করো)\s+(.+)": 
                lambda x: f"calculator {x}" if any(op in x for op in ['+', '-', '*', '/', '%', 'যোগ', 'বিয়োগ', 'গুণ', 'ভাগ']) else None,
            
            # Screenshot patterns in Bengali
            r"(?:ক্যাপচার করো|ছবি তোলো|স্ক্রিনশট নাও)(?:\s+আমার)?\s+(?:স্ক্রিন|ডিসপ্লে)": 
                lambda x: "take screenshot",
            
            # Workflow patterns in Bengali
            r"(?:শুরু করো|চালু করো)(?:\s+আমার)?\s+(?:প্রাতঃকালীন রুটিন|কাজের সেটআপ|বিনোদন|অধ্যয়ন প্রস্তুতি)": 
                lambda x: f"workflow {'_'.join(x.split()[-2:])}",
            r"(?:প্রস্তুত করো|সাজাও)(?:\s+আমার)?\s+(?:কাজ|অধ্যয়ন|বিনোদন|গেমিং|লেখা)": 
                lambda x: f"workflow {x.split()[-1]}_setup",
        }
        
        # Common applications with variations including Bengali names
        self.common_apps = {
            "browser": ["chrome", "firefox", "edge", "safari", "opera", "brave", "ব্রাউজার", "ক্রোম"],
            "editor": ["notepad", "word", "vscode", "visual studio code", "sublime", "atom", "নোটপ্যাড", "ওয়ার্ড"],
            "social": ["facebook", "twitter", "instagram", "linkedin", "whatsapp", "telegram", "ফেসবুক", "টুইটার", "ইনস্টাগ্রাম"],
            "media": ["youtube", "netflix", "spotify", "vlc", "windows media player", "ইউটিউব", "নেটফ্লিক্স"],
            "productivity": ["excel", "powerpoint", "outlook", "gmail", "drive", "onedrive", "এক্সেল", "পাওয়ারপয়েন্ট", "জিমেইল"],
            "bengali_apps": ["avro", "bijoy", "অভ্র", "বিজয়"]
        }
    
    def update_context(self, request, task):
        """Update context tracking with the current request and task"""
        self.context["last_query"] = request
        self.context["last_task"] = task
        
        # Extract potential topics
        words = request.lower().split()
        for word in words:
            if len(word) > 3 and word not in ["what", "when", "where", "this", "that", "then", "about", "with",
                                            "কি", "কে", "কখন", "কোথায়", "এই", "ওই", "তারপর", "সম্পর্কে"]:
                if len(self.context["recent_topics"]) >= 5:
                    self.context["recent_topics"].pop(0)
                self.context["recent_topics"].append(word)
        
        # Update app tracking
        if task.startswith("open "):
            app = task.replace("open ", "").strip()
            self.context["active_apps"].add(app)
        elif task.startswith("close "):
            app = task.replace("close ", "").strip()
            if app in self.context["active_apps"]:
                self.context["active_apps"].remove(app)
    
    def handle_followup_command(self, request):
        """Handle followup commands that rely on context - now supports Bengali"""
        request = request.lower().strip()
        
        # Handle commands that refer to previous context (English and Bengali)
        if request in ["do it again", "repeat that", "one more time", "repeat", "again", 
                      "আবার করো", "আরেকবার", "পুনরায় করো", "রিপিট"]:
            if self.context["last_task"]:
                return self.context["last_task"]
        
        # Handle commands with implicit objects (English)
        if request.startswith("open it") or request == "open":
            if self.context["recent_topics"]:
                return f"open {self.context['recent_topics'][-1]}"
        
        if request.startswith("search for it") or request == "search it":
            if self.context["recent_topics"]:
                return f"google search {self.context['recent_topics'][-1]}"
        
        if request.startswith("play it") or request == "play":
            if self.context["recent_topics"]:
                return f"play {self.context['recent_topics'][-1]}"
        
        # Handle commands with implicit objects (Bengali)
        if request.startswith("এটা খোলো") or request == "খোলো":
            if self.context["recent_topics"]:
                return f"open {self.context['recent_topics'][-1]}"
        
        if request.startswith("এটা খুঁজে দেখাও") or request == "খুঁজে দেখাও":
            if self.context["recent_topics"]:
                return f"google search {self.context['recent_topics'][-1]}"
        
        if request.startswith("এটা প্লে করো") or request == "প্লে করো":
            if self.context["recent_topics"]:
                return f"play {self.context['recent_topics'][-1]}"
        
        # Handle pronouns for both English and Bengali
        pronouns = ["it", "this", "that", "them", "those", "এটা", "ওটা", "এই", "ওই", "এগুলো", "ওগুলো"]
        for pronoun in pronouns:
            if pronoun in request.split():
                for topic in reversed(self.context["recent_topics"]):
                    # Replace the pronoun with the topic
                    new_request = request.replace(pronoun, topic)
                    if new_request != request:
                        return self.analyze_request(new_request)
        
        return None
    
    def analyze_request(self, request):
        """Analyze a natural language request and determine the appropriate task"""
        
        if not request:
            return None
            
        request = request.lower().strip()
        
        # First check if this is a followup command that relies on context
        context_command = self.handle_followup_command(request)
        if context_command:
            return context_command
        
        # Process the request through our patterns
        for pattern, task_generator in self.task_patterns.items():
            match = re.search(pattern, request)
            if match:
                # Get the captured groups
                groups = match.groups()
                if groups:
                    # Filter out None values
                    groups = [g for g in groups if g]
                    if groups:  # Make sure we still have values
                        # Generate the task using the captured groups
                        task = task_generator(*groups)
                        if task:
                            # Update context with this request and task
                            self.update_context(request, task)
                            return task
        
        # If no specific task pattern matches, pass it as a general query
        task = f"general {request}"
        self.update_context(request, task)
        return task
    
    def expand_app_names(self, app_name):
        """Try to match abbreviated app names to common applications - now supports Bengali names"""
        app_name = app_name.lower()
        
        # Check for exact matches in common apps
        for category, apps in self.common_apps.items():
            if app_name in apps:
                return app_name
            
            # Check for partial matches
            for app in apps:
                if app_name in app or app in app_name:
                    return app
        
        return app_name
    
    def preprocess_command(self, command):
        """Preprocess a command to make it more compatible with existing functions"""
        
        # Check if it matches any of our known command prefixes
        known_prefixes = [
            "open ", "close ", "play ", "content ", 
            "google search ", "youtube search ", "download ", 
            "translate ", "weather ", "calculator ", "find file ",
            "general ", "realtime ", "system ", "workflow ",
            # Bengali prefixes
            "খোলো ", "বন্ধ করো ", "প্লে করো ", "কন্টেন্ট ", 
            "গুগল সার্চ ", "ইউটিউব সার্চ ", "ডাউনলোড ", 
            "অনুবাদ করো ", "আবহাওয়া ", "ক্যালকুলেটর ", "ফাইল খুঁজে দেখাও "
        ]
        
        if any(command.startswith(prefix) for prefix in known_prefixes) or command.startswith("take screenshot") or command.startswith("স্ক্রিনশট নাও"):
            # Already structured as a command
            return command
        else:
            # Try to interpret as a natural language request
            return self.analyze_request(command)

# Initialize the smart task handler
smart_handler = SmartTaskHandler()

# Function to handle complex automation workflows
async def execute_workflow(workflow_name, parameters=None):
    """Execute a predefined workflow of multiple automation tasks with customizable parameters"""
    print(f"Executing workflow: {workflow_name} with parameters: {parameters}")
    
    # Define a more extensive set of workflows
    workflows = {
        "morning_routine": [
            "weather current location",
            "news today",
            "open email",
            "open calendar",
            "youtube search morning music"
        ],
        "work_setup": [
            "open chrome",
            "open vscode",
            "open slack",
            "open github",
            "open gmail"
        ],
        "entertainment": [
            "system volume up",
            "open youtube",
            "youtube search popular music videos"
        ],
        "study_setup": [
            "open chrome",
            "open notion",
            "open pdf reader",
            "google search study materials",
            "system volume down"
        ],
        "social_media_check": [
            "open facebook",
            "open twitter",
            "open instagram",
            "open linkedin"
        ],
        "news_update": [
            "google search latest news",
            "youtube search news today",
            "open news website"
        ],
        "development_environment": [
            "open vscode",
            "open terminal",
            "open github desktop",
            "open browser",
            "open stackoverflow"
        ],
        "media_production": [
            "open photoshop",
            "open premiere",
            "open audacity",
            "system volume up"
        ],
        "writing_environment": [
            "open word",
            "open browser",
            "system volume down",
            "open dictionary",
            "google search writing tips"
        ],
        "gaming_setup": [
            "open steam",
            "open discord",
            "system volume up",
            "close unnecessary apps"
        ],
        # Bengali workflows with Bengali names
        "প্রাতঃকালীন_রুটিন": [  # Morning routine in Bengali
            "weather current location",
            "news today",
            "open email",
            "youtube search morning music"
        ],
        "কাজের_সেটআপ": [  # Work setup in Bengali
            "open chrome",
            "open vscode",
            "open slack",
            "open email"
        ],
        "বিনোদন": [  # Entertainment in Bengali
            "system volume up",
            "open youtube",
            "youtube search bengali songs"
        ],
        "অধ্যয়ন_প্রস্তুতি": [  # Study setup in Bengali
            "open chrome",
            "open notion",
            "open pdf reader",
            "google search study materials bengali",
            "system volume down"
        ]
    }
    
    # Smart workflow selection - try to find closest match if not exact
    if workflow_name not in workflows:
        # Check if it's a workflow name with spaces instead of underscores
        workflow_name_underscore = workflow_name.replace(" ", "_")
        if workflow_name_underscore in workflows:
            workflow_name = workflow_name_underscore
        else:
            # Try to find a partial match
            for wf_name in workflows.keys():
                if workflow_name.lower() in wf_name.lower() or wf_name.lower() in workflow_name.lower():
                    workflow_name = wf_name
                    print(f"Found approximate workflow match: {wf_name}")
                    break
    
    if workflow_name in workflows:
        tasks = workflows[workflow_name]
        
        # Apply parameters if provided
        if parameters:
            processed_tasks = []
            for task in tasks:
                for param_key, param_value in parameters.items():
                    placeholder = "{" + param_key + "}"
                    if placeholder in task:
                        task = task.replace(placeholder, param_value)
                processed_tasks.append(task)
            tasks = processed_tasks
        
        # Execute all tasks in the workflow
        for task in tasks:
            await Automation([task])
            await asyncio.sleep(1)  # Small delay between tasks
            
        return True
    else:
        print(f"Workflow '{workflow_name}' not found")
        return False

# Add function to detect and close unnecessary applications
async def close_unnecessary_apps():
    """Close common background applications that might not be needed"""
    apps_to_close = [
        "calculator", "notepad", "paint", "photos", "media player",
        "settings", "snipping tool", "file explorer"
    ]
    
    for app in apps_to_close:
        try:
            await Automation([f"close {app}"])
            await asyncio.sleep(0.5)
        except:
            pass
    
    return True

# Update the Automation function to be more advanced
async def Automation(commands: list[str]):
    # Handle command chaining (e.g., "and" separated commands)
    expanded_commands = []
    for cmd in commands:
        if " and " in cmd.lower() and not cmd.startswith("general ") and not cmd.startswith("realtime "):
            parts = cmd.split(" and ")
            for part in parts:
                expanded_commands.append(part.strip())
        # Handle Bengali "and" (এবং)
        elif " এবং " in cmd.lower() and not cmd.startswith("general ") and not cmd.startswith("realtime "):
            parts = cmd.split(" এবং ")
            for part in parts:
                expanded_commands.append(part.strip())
        else:
            expanded_commands.append(cmd)
    
    commands = expanded_commands
    
    # Handle special commands like "close all" or "বন্ধ করো সব"
    special_commands = [cmd for cmd in commands if cmd == "close all" or cmd == "বন্ধ করো সব"]
    if special_commands:
        for cmd in special_commands:
            await close_unnecessary_apps()
            commands.remove(cmd)
    
    # Handle workflow commands
    workflow_commands = [cmd for cmd in commands if cmd.startswith("workflow ")]
    for cmd in workflow_commands:
        workflow_name = cmd.replace("workflow ", "").strip()
        params = {}  # You can extract parameters here if needed
        await execute_workflow(workflow_name, params)
        commands.remove(cmd)
    
    # Preprocess commands using smart handler if they don't match known patterns
    processed_commands = []
    for cmd in commands:
        if cmd.startswith("workflow "):
            # Already processed above
            continue
        elif any(cmd.startswith(func + " ") for func in KNOWN_FUNCTIONS) or cmd.startswith("take screenshot"):
            processed_commands.append(cmd)
        else:
            processed_cmd = smart_handler.preprocess_command(cmd)
            print(f"Smart handler processed '{cmd}' to '{processed_cmd}'")
            processed_commands.append(processed_cmd)
    
    # Now proceed with the processed commands
    async for result in TranslateAndExecute(processed_commands):
        pass
    return True