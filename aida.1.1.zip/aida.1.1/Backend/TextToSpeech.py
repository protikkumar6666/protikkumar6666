import pygame  # Import pygame library for handling audio playback
import random  # Import random for generating random choices
import asyncio  # Import asyncio for asynchronous operations
import edge_tts  # Import edge_tts for text-to-speech functionality
import os  # Import os for file path handling
from dotenv import dotenv_values  # Import dotenv for reading environment variables
import mtranslate as mt  # Import mtranslate for translation support

# Load environment variables from .env file
env_vars = dotenv_values(".env")
AssistantVoice = env_vars.get("AssistantVoice")  # Get the AssistantVoice from environment variables
InputLanguage = env_vars.get("InputLanguage")  # Get the input language

# Function to translate text to the target language
def TranslateText(text, target_language="bn"):
    try:
        # Check if the text needs translation
        if target_language.lower() == "en" or target_language.lower().startswith("en-"):
            return text
        
        # Add a space after periods for better sentence structure
        text = text.replace(".", ". ")
        
        # Translate the text to the target language
        translated_text = mt.translate(text, target_language, "en")
        
        # Clean up any double spaces
        translated_text = ' '.join(translated_text.split())
        
        # Log the translation for debugging
        print(f"Original text: {text}")
        print(f"Translated to {target_language}: {translated_text}")
        
        # Save the translated text for reference
        with open(r"Data\last_translation.txt", "w", encoding="utf-8") as file:
            file.write(f"Original: {text}\nTranslated: {translated_text}")
            
        return translated_text
    except Exception as e:
        print(f"Translation error in TTS: {e}")
        return text

# Asynchronous function to convert text to an audio file
async def TextToAudioFile(text, voice=None) -> None:
    file_path = r"Data\speech.mp3"  # Define the path where the speech file will be saved
   
    if os.path.exists(file_path):  # Check if the file already exists
        os.remove(file_path)  # If it exists, remove it to avoid overwriting errors
   
    # Use provided voice or default from env
    voice_to_use = voice if voice else AssistantVoice
    
    try:
        # For Bengali voices, preprocess the text for better pronunciation
        if 'bn-' in voice_to_use:
            # Ensure proper spacing for Bengali text
            text = text.replace("।", "। ")  # Add space after Bengali period
            text = ' '.join(text.split())  # Remove double spaces
            
            # Special parameters for Bengali voice - using slower rate for clarity
            communicate = edge_tts.Communicate(text, voice_to_use, pitch='+0Hz', rate='-5%')
        else:
            communicate = edge_tts.Communicate(text, voice_to_use, pitch='+5Hz', rate='+13%')
            
        await communicate.save(r"Data\speech.mp3")  # Save the generated speech as an MP3 file
        print(f"Successfully generated speech with voice: {voice_to_use}")
    except Exception as e:
        print(f"Error generating speech: {e}")
        # Fallback to English if Bengali fails
        if 'bn-' in voice_to_use:
            try:
                # Try an Indian Bengali voice instead
                alternate_voice = "bn-IN-BashkarNeural" if "PradeepNeural" in voice_to_use else "bn-BD-PradeepNeural"
                print(f"Trying alternate Bengali voice: {alternate_voice}")
                communicate = edge_tts.Communicate(text, alternate_voice, pitch='+0Hz', rate='-5%')
                await communicate.save(r"Data\speech.mp3")
                print(f"Successfully generated speech with alternate voice: {alternate_voice}")
                return
            except Exception as e2:
                print(f"Error with alternate Bengali voice: {e2}")
                
            # If all Bengali voices fail, fall back to English
            fallback_voice = "en-US-AriaNeural"
            print(f"Falling back to {fallback_voice}")
            communicate = edge_tts.Communicate(
                "I apologize, but I couldn't speak in Bengali. I'll use English instead.", 
                fallback_voice, 
                pitch='+0Hz', 
                rate='+0%'
            )
            await communicate.save(r"Data\speech.mp3")

# Function to manage Text-to-Speech (TTS) functionality
def TTS(Text, func=lambda r=None: True, voice=None):
    while True:
        try:
            # Convert text to an audio file asynchronously
            asyncio.run(TextToAudioFile(Text, voice))
           
            # Initialize pygame mixer for audio playback
            pygame.mixer.init()
           
            # Load the generated speech file into pygame mixer
            pygame.mixer.music.load(r"Data\speech.mp3")
            pygame.mixer.music.play()  # Play the audio
           
            # Loop until the audio is done playing or the function stops
            while pygame.mixer.music.get_busy():
                if func() == False:  # Check if the external function returns False
                    break
                pygame.time.Clock().tick(10)  # Limit the loop to 10 ticks per second
           
            return True  # Return True if the audio played successfully
       
        except Exception as e:  # Handle any exceptions during the process
            print(f"Error in TTS: {e}")
       
        finally:
            try:
                # Call the provided function with False to signal the end of TTS
                func(False)
                pygame.mixer.music.stop()  # Stop the audio playback
                pygame.mixer.quit()  # Quit the pygame mixer
           
            except Exception as e:  # Handle any exceptions during cleanup
                print(f"Error in finally block: {e}")

# Function to manage Text-to-Speech with additional responses for long text
def TextToSpeech(Text, func=lambda r=None: True):
    # Extract target language from InputLanguage environment variable
    target_language = InputLanguage.split('-')[0] if '-' in InputLanguage else InputLanguage
    
    # Determine if we need to translate (if target language is not English)
    translated_text = Text
    if not (target_language.lower() == "en" or target_language.lower().startswith("en")):
        # Translate the text to the target language
        translated_text = TranslateText(Text, target_language)
    
    Data = str(translated_text).split(".")  # Split the text by periods into a list of sentences
   
    # Bengali specific responses for long text
    if target_language.lower() == "bn":
        responses = [
            "বাকি ফলাফল চ্যাট স্ক্রিনে মুদ্রিত হয়েছে, অনুগ্রহ করে এটি দেখুন স্যার।",
            "বাকি টেক্সট এখন চ্যাট স্ক্রিনে আছে, স্যার, দয়া করে এটি দেখুন।",
            "আপনি বাকি টেক্সট চ্যাট স্ক্রিনে দেখতে পারেন, স্যার।",
            "টেক্সটের বাকি অংশ এখন চ্যাট স্ক্রিনে আছে, স্যার।",
            "স্যার, আরও টেক্সট দেখার জন্য চ্যাট স্ক্রিনে দেখুন।",
            "বাকি উত্তর এখন চ্যাট স্ক্রিনে আছে, স্যার।",
            "স্যার, দয়া করে চ্যাট স্ক্রিনে দেখুন, বাকি উত্তর সেখানে আছে।",
            "আপনি সম্পূর্ণ উত্তর চ্যাট স্ক্রিনে পাবেন, স্যার।"
        ]
    else:
        responses = [
            "The rest of the result has been printed to the chat screen, kindly check it out sir.",
            "The rest of the text is now on the chat screen, sir, please check it.",
            "You can see the rest of the text on the chat screen, sir.",
            "The remaining part of the text is now on the chat screen, sir.",
            "Sir, you'll find more text on the chat screen for you to see.",
            "The rest of the answer is now on the chat screen, sir.",
            "Sir, please look at the chat screen, the rest of the answer is there.",
            "You'll find the complete answer on the chat screen, sir.",
            "The next part of the text is on the chat screen, sir.",
            "Sir, please check the chat screen for more information.",
            "There's more text on the chat screen for you, sir.",
            "Sir, take a look at the chat screen for additional text.",
            "You'll find more to read on the chat screen, sir.",
            "Sir, check the chat screen for the rest of the text.",
            "The chat screen has the rest of the text, sir.",
            "There's more to see on the chat screen, sir, please look.",
            "Sir, the chat screen holds the continuation of the text.",
            "You'll find the complete answer on the chat screen, kindly check it out sir.",
            "Please review the chat screen for the rest of the text, sir.",
            "Sir, look at the chat screen for the complete answer."
        ]
    
    # Use the responses directly for the matching language, otherwise translate
    translated_responses = responses
    if not (target_language.lower() == "en" or target_language.lower() == "bn"):
        translated_responses = [TranslateText(response, target_language) for response in responses]
    
    # If the text is very long (more than 4 sentences and 250 characters), add a response message
    if len(Data) > 4 and len(translated_text) >= 250:
        first_part = " ".join(translated_text.split(".")[:2]) + "."
        tail = random.choice(translated_responses)
        TTS(first_part + " " + tail, func)
    else:
        TTS(translated_text, func)

# Main execution loop
if __name__ == "__main__":
    while True:
        # Prompt user for input and pass it to TextToSpeech function
        TextToSpeech(input("Please enter the text you want to convert to speech: "))